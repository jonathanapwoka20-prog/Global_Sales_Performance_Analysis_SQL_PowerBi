SELECT * FROM Sales_Data;


SELECT SUM(Total_Sales)
FROM Sales_Data;


--- 1. Regional Performance; 
--- a. Sales, Profit By country
SELECT Country,SUM(Total_Sales) AS "Total Sales",
               SUM(Profit) AS "Total Profit"
FROM Sales_Data
GROUP BY Country
ORDER BY SUM(Profit) DESC;


--- b. Average Profit Margin per Country
SELECT Country,
       AVG(
       CASE 
           WHEN Total_Sales <> 0 THEN (Profit / Total_Sales) * 100 
       END) AS "Avg Profit Margin"
FROM Sales_Data
GROUP BY Country;

--- Top 2 Performing country by Revenue/Profit
SELECT TOP 2 Country,SUM(Total_Sales) AS "Total Sales",
               SUM(Profit) AS "Total Profit"
FROM Sales_Data
GROUP BY Country
ORDER BY SUM(Total_Sales) DESC, SUM(Profit);

--- 2. Category Insights
--- a. Category contribution % by country
SELECT Country, Category,
       SUM(Total_Sales) AS "Total Sales",
       SUM(Total_Sales) * 100.0 / SUM(SUM(Total_Sales)) 
                                     OVER (PARTITION BY Country) AS Contribution_Percent
FROM Sales_Data
GROUP BY Country, Category
ORDER BY Country, Contribution_Percent DESC;


--- b. Top 5 selling Categories Globally
SELECT TOP 5 Category, SUM(Total_Sales) AS "Total Sales"
FROM Sales_Data
GROUP BY Category
ORDER BY SUM(Total_Sales) DESC;

--- c. Profitability by category (margin comparison)
SELECT Category, 
       SUM(Profit) AS "Total Profit",
       (SUM(Profit)/SUM(Total_Sales)) * 100 AS Profit_Margin_Percent
FROM Sales_Data
GROUP BY Category
ORDER BY Profit_Margin_Percent DESC;

--- d. Calculate the discount Impact (Amount Lost)
SELECT 
    SUM((Price_per_Unit * Quantity_Purchased) * (Discount_Applied / 100.0)) AS Discount_Impact
FROM Sales_Data;


--- Store Location Analysis
--- a. Sales By store Location

SELECT DISTINCT Store_Location
FROM Sales_Data;

SELECT Store_Location, 
       SUM(Total_Sales) AS "Total Sales"
FROM Sales_Data
GROUP BY Store_Location
ORDER BY "Total Sales" DESC;


--- b. Profitability by Store location TOP 10
SELECT TOP 10 Store_Location, 
       SUM(Profit) AS Profit
FROM Sales_Data
GROUP BY Store_Location
ORDER BY Profit DESC;


--- C. Regional hotspots (best-performing cities) Top 5
SELECT TOP 5 Store_Location, 
       SUM(Total_Sales) AS "Total Sales",
       SUM(Profit) AS Profit
FROM Sales_Data
GROUP BY Store_Location
ORDER BY Profit DESC, "Total Sales" DESC;


--- 4. Sales Rep Benchmarking
--- a. Top 5 Sales Rep Globally
SELECT TOP 5 Sales_Rep,
             SUM(Total_Sales) AS "Total Sales", 
             SUM(Profit) AS Profit
FROM Sales_Data
GROUP BY Sales_Rep
ORDER BY "Total Sales" DESC, Profit DESC;

--- Top 2 Sales Reps per country (Total Sales Rev, Profit)
WITH RankedSales AS (
    SELECT 
        Country,
        Sales_Rep,
        SUM(Total_Sales) AS Total_Sales,
        SUM(Profit) AS Profit,
        ROW_NUMBER() OVER (
            PARTITION BY Country 
            ORDER BY SUM(Total_Sales) DESC
        ) AS RepRank
    FROM Sales_Data
    GROUP BY Country, Sales_Rep
)
SELECT 
    Country,
    Sales_Rep,
    Total_Sales,
    Profit,
    RepRank
FROM RankedSales
WHERE RepRank <= 2
ORDER BY Country, RepRank;

SELECT * FROM Sales_Data


--- b. Sales Rep performance by country
SELECT TOP 5 Country,
             Sales_Rep,
             SUM(Total_Sales) AS "Total Sales", 
             SUM(Profit) AS Profit
FROM Sales_Data
GROUP BY Country, Sales_Rep
ORDER BY "Total Sales" DESC, Profit DESC;

--- c. Top 2 Sales Rep in each country (Using a CTE)

WITH RepSales AS (
    SELECT 
        Country,
        Sales_Rep,
        SUM(Total_Sales) AS Sales,
        ROW_NUMBER() OVER (
            PARTITION BY Country 
            ORDER BY SUM(Total_Sales) DESC
        ) AS RowNum
    FROM Sales_Data
    GROUP BY Country, Sales_Rep
)
SELECT Country, Sales_Rep, Sales
FROM RepSales
WHERE RowNum <= 2
ORDER BY Country, Sales DESC;


--- d. Average deal size per sales rep (TOP 10)
SELECT TOP 10 Country,
              Sales_Rep, 
              AVG(Total_Sales) AS "Average Sales"
FROM Sales_Data
GROUP BY Country, Sales_Rep
ORDER BY "Average Sales" DESC;


--- 5. Customer Demographics
--- a. Sales by Customer Age Group

SELECT * FROM Sales_Data;

SELECT Customer_Age_Group, 
       SUM(Total_Sales) AS "Total Sales",
       SUM(Profit) AS Profit
FROM Sales_Data
GROUP BY Customer_Age_Group
ORDER BY "Total Sales" DESC;

---b .Total/Avg Sales, Sum/Avg By Gender
SELECT Customer_Gender, 
       SUM(Total_Sales) AS "Total Sales",
       AVG(Total_Sales) AS "Average Sales",
       SUM(Profit) AS "Total Profit",
       AVG(Profit) AS "Average Profit"
FROM Sales_Data
GROUP BY Customer_Gender
ORDER BY "Total Sales" DESC, "Average Sales" DESC, "Total Profit" DESC, "Average Profit" DESC;


--- c. Profitability by demographic segment
SELECT Customer_Age_Group,
       Customer_Gender,
       SUM(Total_Sales) AS "Total Sales",
       SUM(Profit) AS Profit,
       (SUM(Profit)/SUM(Total_Sales)) * 100 AS Profit_Margin_Percent
FROM Sales_Data
GROUP BY Customer_Age_Group, Customer_Gender
ORDER BY Profit_Margin_PercenT DESC;


--- Payment Method
--- a. Sales/Profit By Payment method

SELECT Payment_Method,
       SUM(Total_Sales) AS "Total Sales",
       AVG(Total_Sales) AS "Average Sales",
       SUM(Profit) AS "Total Profit",
       AVG(Profit) AS "Average Profit"
FROM Sales_Data
GROUP BY Payment_Method
ORDER BY "Total Sales" DESC, "Average Sales" DESC, "Total Profit" DESC, "Average Profit";

--- b. Payment method preference by country
SELECT Country,
       Payment_Method,
       SUM(Total_Sales) AS "Total Sales",
       AVG(Total_Sales) AS "Average Sales",
       SUM(Profit) AS "Total Profit",
       AVG(Profit) AS "Average Profit"
FROM Sales_Data
GROUP BY Country, Payment_Method
ORDER BY "Total Sales" DESC, "Average Sales" DESC, "Total Profit" DESC, "Average Profit";


--- 7. Time-Based Analysis
--- a. Monthly sales/profit trend. I have created a CTE to return month names as well
WITH MonthCTE AS (
    SELECT 
        MONTH(Date) AS MonthNumber,
        CASE 
            WHEN MONTH(Date) = 1 THEN 'January'
            WHEN MONTH(Date) = 2 THEN 'February'
            WHEN MONTH(Date) = 3 THEN 'March'
            WHEN MONTH(Date) = 4 THEN 'April'
            WHEN MONTH(Date) = 5 THEN 'May'
            WHEN MONTH(Date) = 6 THEN 'June'
            WHEN MONTH(Date) = 7 THEN 'July'
            WHEN MONTH(Date) = 8 THEN 'August'
            WHEN MONTH(Date) = 9 THEN 'September'
            WHEN MONTH(Date) = 10 THEN 'October'
            WHEN MONTH(Date) = 11 THEN 'November'
            WHEN MONTH(Date) = 12 THEN 'December'
        END AS MonthName,
        Total_Sales, Profit
    FROM Sales_Data
)
SELECT 
    MonthNumber AS [Month],
    MonthName,
    SUM(Total_Sales) AS [Total Sales],
    SUM(Profit) AS Profit
FROM MonthCTE
GROUP BY MonthNumber, MonthName
ORDER BY MonthNumber ASC;


--- b. Quarterly Sales/Profit Trends
SELECT DATEPART(QUARTER, Date) AS Quarter,
       SUM(Total_Sales) AS "Total Sales", 
       SUM(Profit) AS Profit
FROM Sales_Data
GROUP BY DATEPART(QUARTER, Date)
ORDER BY Quarter ASC;


--- c. Seasonal Peaks (using Month)
SELECT MONTH(Date) AS Month,
       SUM(Total_Sales) AS "Total Sales",
       SUM(Profit) AS Profit
FROM Sales_Data
GROUP BY MONTH(Date)
ORDER BY MONTH(Date) ASC;

--- d. Daily trend in Total Sales Rev and Profit
SELECT DATENAME(WEEKDAY, Date) AS "Day of the Week",
       SUM(Total_Sales) AS "Total Sales Rev",
       SUM(Profit) AS Profit
FROM Sales_Data
GROUP BY DATENAME(WEEKDAY, Date);

--- e. Daily Totals Sales and Profit Trend. I have created a CTE to asign day numbers to weekdays from 1 -7
WITH DayNumberCTE AS (
    SELECT 
        DATENAME(WEEKDAY, Date) AS Day_Name,
        CASE
            WHEN DATENAME(WEEKDAY, Date) = 'Monday' THEN 1
            WHEN DATENAME(WEEKDAY, Date) = 'Tuesday' THEN 2
            WHEN DATENAME(WEEKDAY, Date) = 'Wednesday' THEN 3
            WHEN DATENAME(WEEKDAY, Date) = 'Thursday' THEN 4
            WHEN DATENAME(WEEKDAY, Date) = 'Friday' THEN 5
            WHEN DATENAME(WEEKDAY, Date) = 'Saturday' THEN 6
            WHEN DATENAME(WEEKDAY, Date) = 'Sunday' THEN 7
        END AS Day_Number,
        Total_Sales,
        Profit
    FROM Sales_Data
)
SELECT 
    Day_Number,
    Day_Name,
    SUM(Total_Sales) AS Total_Sales,
    SUM(Profit) AS Profit
FROM DayNumberCTE
GROUP BY Day_Number, Day_Name
ORDER BY Day_Number ASC;


SELECT * FROM Sales_Data































































